API
===

.. autosummary::
   :toctree: generated

   DP_epidemiology